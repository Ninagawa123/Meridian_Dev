# Meridian
MERIDIAN is an open source project to facilitate the digital twinning of humanoids and to enable everyone to enjoy its research and development.

This is a library to drive a communication system for humanoid robots.
It operates numerous servo motors and 9-axis sensors at 100 Hz and links status information with a PC in real time.

We are currently in the process of porting the following repositories to the corresponding functionality in the library. Please take a look.

https://github.com/Ninagawa123/Meridian_TWIN
