#ifndef __MERIDIAN_MOVEMENT_FIRST_IK_H__
#define __MERIDIAN_MOVEMENT_FIRST_IK_H__

#include "config.h"
#include "main.h"

//==================================================================================================
//  逆運動学関連の処理  -----------------------------------------------------------------------------
//==================================================================================================

/// @brief スタブ関数.
/// @return 常にfalseを返す.
bool mrd_ik_x() {
  return false;
}

#endif // __MERIDIAN_MOVEMENT_FIRST_IK_H__
