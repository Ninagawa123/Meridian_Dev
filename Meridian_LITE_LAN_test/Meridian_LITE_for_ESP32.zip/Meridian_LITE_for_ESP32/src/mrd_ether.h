#ifndef __MERIDIAN_ETHER_H__
#define __MERIDIAN_ETHER_H__

// ヘッダファイルの読み込み
#include "config.h"
#include "keys.h"

// ライブラリ導入 (標準Ethernetライブラリ)
#include <Ethernet.h>
#include <EthernetUdp.h>
#include <SPI.h>

EthernetUDP udp_et; // Ethernet設定

const uint8_t ETHER_LOCAL_IP[4] = {192, 168, 90, 2};
const uint8_t ETHER_GATEWAY[4] = {192, 168, 90, 1};
const uint8_t ETHER_SUBNET[4] = {255, 255, 255, 0};
const uint8_t ETHER_DNS[4] = {8, 8, 8, 8};

byte mac_et[] = {0x02, 0xXX, 0xXX, 0xXX, 0xXX, 0xXX}; // W5500のMACアドレス

//==================================================================================================
// Ethernet 関連の処理
//==================================================================================================

/// @brief Ethernetを初期化する（標準Ethernetライブラリ用）
/// @param a_udp 使用するEthernetUDPのインスタンス
/// @param a_cs_pin W5500のCSピン番号
/// @param a_serial 出力先シリアルの指定.
/// @return 初期化に成功した場合はtrueを, 失敗した場合はfalseを返す.
bool mrd_ether_init(EthernetUDP &a_udp, int a_cs_pin, HardwareSerial &a_serial) {
  // MACアドレス表示
  a_serial.print("Ether MAC Address: ");
  for (int i = 0; i < 6; i++) {
    if (mac_et[i] < 16)
      a_serial.print("0");
    a_serial.print(mac_et[i], HEX);
    if (i < 5)
      a_serial.print(":");
  }
  a_serial.println();

  a_serial.println("Testing W5500 connection...");

  // 標準Ethernetライブラリでの初期化
  Ethernet.init(a_cs_pin);
  IPAddress local_ip(ETHER_LOCAL_IP[0], ETHER_LOCAL_IP[1], ETHER_LOCAL_IP[2], ETHER_LOCAL_IP[3]);
  Ethernet.begin(mac_et, local_ip);

  a_serial.print("IP Address: ");
  a_serial.println(Ethernet.localIP());

  if (Ethernet.localIP() == local_ip) {
    a_serial.println("SUCCESS!");
  } else {
    a_serial.println("FAILED - Check hardware connections");
    return false;
  }

  // UDP開始
  a_udp.begin(UDP_RECV_PORT);
  a_serial.print("UDP listening on port: ");
  a_serial.println(UDP_RECV_PORT);

  return true;
}

/// @brief 第一引数のMeridim配列にUDP経由でデータを受信, 格納する.
/// @param a_meridim_bval バイト型のMeridim配列
/// @param a_len バイト型のMeridim配列の長さ
/// @param a_udp 使用するEthernetUDPのインスタンス
/// @return 受信した場合はtrueを, 受信しなかった場合はfalseを返す.
bool mrd_ether_udp_receive(byte *a_meridim_bval, int a_len, EthernetUDP &a_udp) {
  int packet_size = a_udp.parsePacket();
  if (packet_size >= a_len) {
    a_udp.read(a_meridim_bval, a_len);

    // 受信元情報を取得（デバッグ用）
    IPAddress remote_ip = a_udp.remoteIP();
    uint16_t remote_port = a_udp.remotePort();

    return true;
  }
  return false; // バッファにデータがない
}

/// @brief 第一引数のMeridim配列のデータをUDP経由で指定したIPアドレス、ポートに送信する.
/// @param a_meridim_bval バイト型のMeridim配列
/// @param a_len バイト型のMeridim配列の長さ
/// @param a_udp 使用するEthernetUDPのインスタンス
/// @param a_send_ip 送信先IPアドレス
/// @param a_send_port 送信先ポート番号
/// @return 送信完了時にtrueを返す.
bool mrd_ether_udp_send(byte *a_meridim_bval, int a_len, EthernetUDP &a_udp, IPAddress a_send_ip, int a_send_port) {
  int result = a_udp.beginPacket(a_send_ip, a_send_port);
  if (result == 0) {
    return false; // パケット開始に失敗
  }

  size_t bytes_written = a_udp.write(a_meridim_bval, a_len);
  if (bytes_written != a_len) {
    return false; // 書き込みサイズが異なる
  }

  result = a_udp.endPacket();
  return (result == 1); // 成功時は1を返す
}

/// @brief Ethernetの接続状態を確認する.
/// @return 接続されている場合はtrueを, 切断されている場合はfalseを返す.
bool mrd_ether_check_connection() {
  return (Ethernet.localIP() != IPAddress(0, 0, 0, 0));
}

/// @brief Ethernetのハードウェア状態を確認する.
/// @return ハードウェアが検出された場合はtrueを返す.
bool mrd_ether_check_hardware() {
  // 標準Ethernetライブラリでのハードウェア状態確認
  if (Ethernet.hardwareStatus() == EthernetNoHardware) {
    return false;
  }
  return true;
}

/// @brief Ethernetの現在のIPアドレスを取得する.
/// @return 現在のIPアドレス
IPAddress mrd_ether_get_local_ip() {
  return Ethernet.localIP();
}

/// @brief Ethernetの詳細状態を表示する.
/// @param a_serial 出力先シリアルの指定.
void mrd_ether_print_status(HardwareSerial &a_serial) {
  a_serial.println("=== Ethernet Status ===");

  // 標準Ethernetライブラリでのハードウェア状態表示
  switch (Ethernet.hardwareStatus()) {
  case EthernetNoHardware:
    a_serial.println("Hardware: Not found");
    break;
  case EthernetW5100:
    a_serial.println("Hardware: W5100");
    break;
  case EthernetW5200:
    a_serial.println("Hardware: W5200");
    break;
  case EthernetW5500:
    a_serial.println("Hardware: W5500");
    break;
  default:
    a_serial.println("Hardware: Unknown");
    break;
  }

  // リンク状態の表示
  switch (Ethernet.linkStatus()) {
  case Unknown:
    a_serial.println("Link: Unknown");
    break;
  case LinkON:
    a_serial.println("Link: Connected");
    break;
  case LinkOFF:
    a_serial.println("Link: Disconnected");
    break;
  default:
    a_serial.println("Link: Unknown status");
    break;
  }

  // ネットワーク情報
  a_serial.print("Local IP: ");
  a_serial.println(Ethernet.localIP());
  a_serial.print("Gateway: ");
  a_serial.println(Ethernet.gatewayIP());
  a_serial.print("Subnet: ");
  a_serial.println(Ethernet.subnetMask());
  a_serial.print("DNS: ");
  a_serial.println(Ethernet.dnsServerIP());

  a_serial.println("=====================");
}

/// @brief Ethernetの接続を維持する（DHCP更新等）.
/// @return maintain処理の結果を返す.
int mrd_ether_maintain() {
  // 標準Ethernetライブラリのmaintain()関数を使用
  return Ethernet.maintain();
}

#endif // __MERIDIAN_ETHER_H__