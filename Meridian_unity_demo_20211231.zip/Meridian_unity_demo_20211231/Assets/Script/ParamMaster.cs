﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// meridian_20211231_unity_ParamMaster.cs
// 各オブジェクトから送られてきたデータを格納する。
// 画面上のフィギアはこのデータを元に表示する

public class ParamMaster : MonoBehaviour
{
    //meridimの値
    public static short[] r_meridim = new short[90];//meridim92の受信用
    public static short[] s_meridim = new short[90];//meridim92の送信用

    //meridimのインスペクター表示用
    public short[] r_meridim_disp = new short[90];//meridim92の受信用
    public short[] s_meridim_disp = new short[90];//meridim92の送信用

    //public float test = 0;
    public static float[] ServoAnglesL = new float[20];//サーボの現在位置
    public static float[] ServoAnglesR = new float[20];//サーボの現在位置
    //サーボの現在位置 = サーボの初期補正値 + (サーボの移動差分*サーボの回転補正値)

    //ServoAnglesLRのインスペクター表示用
    public float[] ServoAnglesL_disp = new float[20];//サーボの現在位置
    public float[] ServoAnglesR_disp = new float[20];//サーボの現在位置


    public static float[] ServoAnglesL_UI = new float[20];//UnityUIからの入力を一旦格納
    public static float[] ServoAnglesR_UI = new float[20];//UnityUIからの入力を一旦格納

    public static float[] ServoAnglesL_init = new float[20];//サーボの初期位置補正値(表示用？)
    public static float[] ServoAnglesR_init = new float[20];//サーボの初期位置補正値(表示用？)

    public static float[] ServoAnglesL_pn = new float[20];//サーボの回転補正値
    public static float[] ServoAnglesR_pn = new float[20];//サーボの回転補正値

    //辻褄合わせ用の送信用回転補正
    public static float[] ServoAnglesL_pns = new float[20];//辻褄合わせ用の送信用サーボの回転補正値
    public static float[] ServoAnglesR_pns = new float[20];//辻褄合わせ用の送信用サーボの回転補正値


    public static float[] ServoAnglesL_diff = new float[20];//サーボの増減分
    public static float[] ServoAnglesR_diff = new float[20];//サーボの増減分

    public static int[] ServoCommandL_r = new int[15];//サーボコマンド受信用
    public static int[] ServoCommandR_r = new int[15];//サーボコマンド受信用

    public static int[] ServoCommandL_s = new int[15];//サーボコマンド送信用
    public static int[] ServoCommandR_s = new int[15];//サーボコマンド送信用

    //前回の値
    public static float[] ServoAnglesL_past = new float[20];//サーボの前回位置
    public static float[] ServoAnglesR_past = new float[20];//サーボの前回位置

    //計算モーション用の配列
    public static float[] ServoAnglesL_motion = new float[20];//計算モーション用のサーボの増減分
    public static float[] ServoAnglesR_motion = new float[20];//計算モーション用のサーボの増減分

    public float motion_count = 0;//計算モーションのカウント用
    public float motion_val_a = 0;//計算モーション用の変数

    //センサー用の配列　それぞれ100倍された値が入ってくる
    public static float[] ACxyz_GYxyz_CPxyz_TP_RPY = new float[13];//11,12,13番がRPYの100倍値

    //センサー用の配列　それぞれ100倍された値が入ってくる
    public static bool toggle2 = false;//計算制御テスト用のトグル
    public bool toggle2_disp = false;//計算制御テスト用のトグル

    private void Start()
    {
        for (int i = 0; i < 20; i++)
        {
            ServoAnglesL[i] = 0;
            ServoAnglesR[i] = 0;
        }


        //サーボの初期位置補正（degree）
        ServoAnglesL_init[0] = 0;
        ServoAnglesL_init[1] = 0;
        ServoAnglesL_init[2] = 0;
        ServoAnglesL_init[3] = 0;
        ServoAnglesL_init[4] = 0;
        ServoAnglesL_init[5] = 0;
        ServoAnglesL_init[6] = 0;
        ServoAnglesL_init[7] = 0;
        ServoAnglesL_init[8] = 0;
        ServoAnglesL_init[9] = 0;
        ServoAnglesL_init[10] = 0;
        ServoAnglesR_init[0] = 0;
        ServoAnglesR_init[1] = 0;
        ServoAnglesR_init[2] = 0;
        ServoAnglesR_init[3] = 0;
        ServoAnglesR_init[4] = 0;
        ServoAnglesR_init[5] = 0;
        ServoAnglesR_init[6] = 0;
        ServoAnglesR_init[7] = 0;
        ServoAnglesR_init[8] = 0;
        ServoAnglesR_init[9] = 0;
        ServoAnglesR_init[10] = 0;

        //サーボ回転方向の正負方向補正
        ServoAnglesL_pn[0] = +1;
        ServoAnglesL_pn[1] = +1;
        ServoAnglesL_pn[2] = +1;//?
        ServoAnglesL_pn[3] = +1;
        ServoAnglesL_pn[4] = +1;//?
        ServoAnglesL_pn[5] = +1;
        ServoAnglesL_pn[6] = +1;
        ServoAnglesL_pn[7] = +1;
        ServoAnglesL_pn[8] = +1;
        ServoAnglesL_pn[9] = +1;
        ServoAnglesL_pn[10] = +1;
        ServoAnglesR_pn[0] = +1;
        ServoAnglesR_pn[1] = +1;
        ServoAnglesR_pn[2] = +1;
        ServoAnglesR_pn[3] = +1;
        ServoAnglesR_pn[4] = +1;
        ServoAnglesR_pn[5] = +1;
        ServoAnglesR_pn[6] = +1;
        ServoAnglesR_pn[7] = +1;
        ServoAnglesR_pn[8] = +1;
        ServoAnglesR_pn[9] = +1;
        ServoAnglesR_pn[10] = +1;

        /*
        //辻褄合わせ用の送信用のサーボ回転方向の正負方向補正
        ServoAnglesL_pns[0] = +1;
        ServoAnglesL_pns[1] = +1;
        ServoAnglesL_pns[2] = +1;
        ServoAnglesL_pns[3] = -1;
        ServoAnglesL_pns[4] = +1;
        ServoAnglesL_pns[5] = -1;
        ServoAnglesL_pns[6] = +1;
        ServoAnglesL_pns[7] = +1;
        ServoAnglesL_pns[8] = -1;
        ServoAnglesL_pns[9] = +1;
        ServoAnglesL_pns[10] = -1;
        ServoAnglesR_pns[0] = +1;
        ServoAnglesR_pns[1] = +1;
        ServoAnglesR_pns[2] = -1;
        ServoAnglesR_pns[3] = -1;
        ServoAnglesR_pns[4] = +1;
        ServoAnglesR_pns[5] = +1;
        ServoAnglesR_pns[6] = -1;
        ServoAnglesR_pns[7] = +1;
        ServoAnglesR_pns[8] = +1;
        ServoAnglesR_pns[9] = +1;
        ServoAnglesR_pns[10] = +1;
        */

    }


    void FixedUpdate()//パラムマスターの計算
    {

        //計算モーション用の作成
        for (int i = 0; i < 15; i++)
        {
            ServoAnglesL_motion[i] = Mathf.Sin(motion_count) * 3;//計算モーション用のサーボの増減分
            ServoAnglesR_motion[i] = 5;//計算モーション用のサーボの増減分
        }

        motion_count = motion_count + 0.01f;//計算モーションのカウント用
        motion_val_a = motion_count;//計算モーション用の変数




        ///*
        for (int i = 0; i < 20; i++)//サーボの位置を計算
        {
            ServoAnglesL[i] = ServoAnglesL_init[i] + (ServoAnglesL_diff[i] * ServoAnglesL_pn[i]);
            ServoAnglesR[i] = ServoAnglesR_init[i] + (ServoAnglesR_diff[i] * ServoAnglesR_pn[i]);
            //サーボの現在位置 = サーボの初期補正値 + (サーボの移動差分*サーボの回転補正値)
        }
        //*/

        for (int i = 0; i < 15; i++)
        {
            Debug.Log(ServoAnglesL[5]);
            Debug.Log(ServoAnglesL_past[5]);
            Debug.Log(Mathf.Abs(ServoAnglesL[5] - ServoAnglesL_past[5]));
            if (ServoCommandL_s[i] == 0)
            {
                if (Mathf.Abs(ServoAnglesL[i] - ServoAnglesL_past[i]) > 0.35)//誤差が１以上なら反映（プルプル防止）
                {
                    ServoAnglesL[i] = ServoAnglesL_init[i] + (ServoAnglesL_diff[i] * ServoAnglesL_pn[i]);
                    ServoAnglesL_past[i] = ServoAnglesL[i];
                }
                else
                {
                    ServoAnglesL[i] = ServoAnglesL_past[i];
                }
            }
            else//ServoCommandL_s[i] == 1
            {
                if (toggle2 == true)
                {
                    ServoAnglesL_diff[i] = ServoAnglesL_motion[i];
                }
                else
                {
                    ServoAnglesL_diff[i] = ServoAnglesL_UI[i];
                }
                ServoAnglesL_past[i] = ServoAnglesL_diff[i];
                //ServoAnglesL[i] = ServoAnglesL_init[i] + (ServoAnglesL_diff[i] * ServoAnglesL_pn[i]);
                ServoAnglesL[i] = ServoAnglesL_init[i] + ServoAnglesL_diff[i];

            }

            if (ServoCommandR_s[i] == 0)
            {
                if (Mathf.Abs(ServoAnglesR[i] - ServoAnglesR_past[i]) > 0.35)//誤差が１以上なら反映（プルプル防止）
                {
                    ServoAnglesR[i] = ServoAnglesR_init[i] + (ServoAnglesR_diff[i] * ServoAnglesR_pn[i]);
                    ServoAnglesR_past[i] = ServoAnglesR[i];
                }
                else
                {
                    ServoAnglesR[i] = ServoAnglesR_past[i];
                }
            }
            else//ServoCommandR_s[i] == 1
            {
                if (toggle2 == true)
                {
                    ServoAnglesR_diff[i] = ServoAnglesR_motion[i];
                }
                else
                {
                    ServoAnglesR_diff[i] = ServoAnglesR_UI[i];
                }
                ServoAnglesR_past[i] = ServoAnglesR_diff[i];
                //ServoAnglesR[i] = ServoAnglesR_init[i] + (ServoAnglesR_diff[i] * ServoAnglesR_pn[i]);
                ServoAnglesR[i] = ServoAnglesR_init[i] + ServoAnglesR_diff[i];
            }
        }

        for (int i = 0; i < 92; i++)//meridimをインスペクター表示用に転記
        {
            r_meridim_disp[i] = r_meridim[i];
            s_meridim_disp[i] = s_meridim[i];
        }
        for (int i = 0; i < 15; i++)//ServoAnglesLRをインスペクター表示用に転記
        {
            ServoAnglesL_disp[i] = ServoAnglesL[i];
            ServoAnglesR_disp[i] = ServoAnglesR[i];
        }
    }


    private void Update()
    {
        toggle2_disp = toggle2;//計算制御テスト用のトグル
    }
}
