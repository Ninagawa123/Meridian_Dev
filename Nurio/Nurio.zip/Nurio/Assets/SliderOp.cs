﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class SliderOp : MonoBehaviour
{
    private GameObject parent;
    public int servoNum;

    InputField inputField;


    private GameObject paramserver;
    private ParamServer script;
    private GameObject blockname;
    //private Name namescript;
    private Slider slider;
    //public String lR;

    private string debug;

    // Start is called before the first frame update
    void Start()
    {
        inputField = GetComponentInChildren<InputField>();

        paramserver = GameObject.Find("ParamServer");
        slider = GetComponent<Slider>();
        blockname = transform.parent.gameObject;
        parent = transform.parent.parent.gameObject;
        servoNum = Convert.ToInt32((parent.name.Substring(1,2)));
        //servoNum = Convert.ToInt32((parent.name.Substring(parent.name.Length - 2)));
        //namescript = blockname.GetComponent<Name>();
        script = paramserver.GetComponent<ParamServer>();
    }

    // Update is called once per frame
    void Update()
    {
        //slider = GameObject.Find("Slider").GetComponent<Slider>();

    }

    public void SlidernewValue(float newValue)
    {

            //script = paramserver.GetComponent<ParamServer>();

        /*
            if (namescript.blocklr == "L")
            {
                script.ServoAnglesL[servoNum] = newValue;
            }
            else if (namescript.blocklr == "R")
            {
                script.ServoAnglesR[servoNum] = newValue;
            }
            else
            {
                Debug.Log("LR error. " + namescript.blocklr);
            }

        */
        debug = null;
        debug = "L";
        foreach (int i in script.ServoAnglesL)
        {
            debug = debug + i+",";
            //Debug.Log(i);
        }
        debug = debug + " R";
        foreach (int i in script.ServoAnglesR)
        {
            debug = debug + i + ",";
            //Debug.Log(i);
        }
        Debug.Log(debug);
        Debug.Log("--");
    }
}