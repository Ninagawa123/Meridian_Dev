﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Program2 : MonoBehaviour
{
    private GameObject paramserver;
    private ParamServer script;

    private float[] angle;

    public float phi_roll = 0f;
    public float theta_pitch = 0f;
    public float psi_yaw = 0f;
    public float r;
    public int i;

    //肩の絶対座標
    public float point_W_start_x = 0;
    public float point_W_start_y = 0.09665f;
    public float point_W_start_z = 0.4835f;

    //public float point_x0 = 0;
    //public float point_y0 = 0;
    //public float point_z0 = 0;

    public float point_x = 0;//元の位置
    public float point_y = 0;//元の位置
    public float point_z = 0;//元の位置

    public float point_x1 = 0;//回転後の位置
    public float point_y1 = 0;//回転後の位置
    public float point_z1 = 0;//回転後の位置

    public float LarmLength2 = 0.30610f;

    // Start is called before the first frame update
    void Start()
    {
        paramserver = GameObject.Find("ParamServer");
        script = paramserver.GetComponent<ParamServer>();
        angle = script.ServoAnglesL;
        //r = script.LarmLength;
        r = LarmLength2;


        //肩の位置に黄色キューブを設置
        var cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        cube.transform.localScale = new Vector3(0.04f, 0.04f, 0.04f);
        cube.transform.position = new Vector3( -point_W_start_y, point_W_start_z, point_W_start_x);
        //cube.transform.position = new Vector3 (point_W_start_x, point_W_start_y, point_W_start_z);
        cube.GetComponent<Renderer>().material.color = Color.yellow;

        //手先の位置に紫キューブを設置
        var cube2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
        cube2.transform.localScale = new Vector3(0.04f, 0.04f, 0.04f);
        cube2.transform.position = new Vector3(-point_W_start_y, point_W_start_z - r, point_W_start_x);
        cube2.GetComponent<Renderer>().material.color = Color.magenta;

    }


    // Update is called once per frame
    void Update()
    {
        float sr = Mathf.Sin(phi_roll * Mathf.Deg2Rad);
        float cr = Mathf.Cos(phi_roll * Mathf.Deg2Rad);
        float sp = Mathf.Sin(theta_pitch * Mathf.Deg2Rad);
        float cp = Mathf.Cos(theta_pitch * Mathf.Deg2Rad);
        float sy = Mathf.Sin(psi_yaw * Mathf.Deg2Rad);
        float cy = Mathf.Cos(psi_yaw * Mathf.Deg2Rad);

        //ロールピッチヨーの回転計算させるプログラム。教科書p40。
        point_x = 0;//肩を原点としたときの点の初期位置
        point_y = 0;//肩を原点としたときの点の初期位置
        point_z = -r;//肩を原点としたときの点の初期位置

        //回転を計算
        point_x1 = 3*r*((point_x * (cy * cp)) + (point_y * (- (sy * cr) +  (cy * sp * sr))) + (point_z * ((sy * sr)  +  (cy * sp * cr))));
        point_y1 = 3*r*((point_x * (sy * cp)) + (point_y * (cy * cr + sy * sp * sr)) + (point_z * (- (cy * sr) + (sy * sp * cr))));
        point_z1 = 3*r*((point_x * (-sp)) + (point_y * (cp * sr)) + (point_z * (cp * cr)));

        //ParamServerに送信
        script.Point1_pos[0] = point_W_start_x + point_x1;//肩を原点するよう並行移動
        script.Point1_pos[1] = point_W_start_y + point_y1;//肩を原点するよう並行移動
        script.Point1_pos[2] = point_W_start_z + point_z1;//肩を原点するよう並行移動


        script.ServoAnglesL[2] = phi_roll;
        script.ServoAnglesL[3] = -theta_pitch;
        script.ServoAnglesL[1] = psi_yaw;


        //script.ServoAnglesL[2] = theta_pitch;

        phi_roll = phi_roll + 3;
        //theta_pitch = theta_pitch + 3;
        //psi_yaw = psi_yaw + 3;

        if (phi_roll > 360)
        {
            phi_roll = 0;
        }

        if (theta_pitch > 360)
        {
            theta_pitch = 0;
        }

        if (psi_yaw > 360)
        {
            psi_yaw = 0;
        }




    }
}

        /*
        { script = paramserver.GetComponent<ParamServer>();

        if (lR == "L")
        {
            angle = script.ServoAnglesL;
        }
        else
        {
            angle = script.ServoAnglesR;
        }

        Vector3 rot = this.transform.localEulerAngles;

        rot.x = 0;
        rot.y = 0;
        rot.z = 0;

        if (aXIS == "Y")
        {
            rot.y = angle[iD] * dIRECTION;
        }
        else if (aXIS == "Z")
        {
            rot.z = angle[iD] * dIRECTION;
        }
        else
        {
            rot.x = angle[iD] * dIRECTION;
        }

        this.transform.localEulerAngles = rot;

    }
}

*/