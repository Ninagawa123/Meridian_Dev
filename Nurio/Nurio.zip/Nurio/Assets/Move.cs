﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Move : MonoBehaviour
{
    private GameObject paramserver;
    private ParamServer script;
    private GameObject parent;
    public Slider slider;

    //public Text text;
    // Start is called before the first frame update
    void Start()
    {
        paramserver = GameObject.Find("ParamServer");
        parent = transform.parent.gameObject;
        slider = GetComponent<Slider>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void SlidernewValue(float newValue)
    {
        slider = GetComponent<Slider>();
        script = paramserver.GetComponent<ParamServer>();

        //Debug.Log(parent.name);
        if (parent.name == "x")
        {
            script.BodyCenter_pos[1] = newValue * 0.5f;
        }
        else if (parent.name == "y")
        {
            script.BodyCenter_pos[2] = 0.2887f + newValue * 0.5f;
        }
        else if (parent.name == "z")
        {
            script.BodyCenter_pos[0] = newValue * 0.5f;
        }
        else if (parent.name == "rotY")
        {
            script.ServoAnglesL[6] = newValue * 180f;
        }
        else if (parent.name == "rotR")
        {
            script.ServoAnglesL[8] = newValue * 180f;
        }
        else {
            Debug.Log("Move Error");
        }
    }
}
