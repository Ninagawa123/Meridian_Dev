﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ID_BODY : MonoBehaviour
{
    public string lR;
    public int iD;
    public string aXIS;
    public int dIRECTION;
    private float[] angle;
    private GameObject paramserver;
    private ParamServer script;

    // Start is called before the first frame update
    void Start()
    {
        paramserver = GameObject.Find("ParamServer");
    }

    // Update is called once per frame
    void Update()
    {
        script = paramserver.GetComponent<ParamServer>();

        Vector3 pos = this.transform.localPosition;

        pos.x = -script.BodyCenter_pos[1];
        pos.y = script.BodyCenter_pos[2];
        pos.z = script.BodyCenter_pos[0];

        this.transform.localPosition = pos;

        if (lR == "L")
        {
            angle = script.ServoAnglesL;
        }
        else
        {
            angle = script.ServoAnglesR;
        }

        Vector3 rot = this.transform.localEulerAngles;

        rot.x = 0;
        rot.y = 0;
        rot.z = 0;

        if (aXIS == "Y")
        {
            rot.y = angle[iD] * dIRECTION;
        }
        else if (aXIS == "Z")
        {
            rot.z = angle[iD] * dIRECTION;
        }
        else
        {
            rot.x = angle[iD] * dIRECTION;
        }

        this.transform.localEulerAngles = rot;

    }
}