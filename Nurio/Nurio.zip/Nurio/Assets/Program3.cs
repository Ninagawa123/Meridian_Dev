﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Program3 : MonoBehaviour

{
    private GameObject paramserver;
    private ParamServer script;

    private float[] angle;

    public float theta = 0f;

    public float[] eax = new float[3];
    public float[] eay = new float[3];
    public float[] eaz = new float[3];


    //肩の絶対座標
    public float point_W_start_x = 0;
    public float point_W_start_y = 0;
    public float point_W_start_z = 0.2f;

    public float point_pos_x=0;
    public float point_pos_y=0;
    public float point_pos_z=0;

    public float point_rot_x_roll=0;
    public float point_rot_y_pitch=0;
    public float point_rot_z_yaw=0;

    public float point_rot_x_roll_2 = 0; //マイフレーム移動角度
    public float point_rot_y_pitch_2 = 0;
    public float point_rot_z_yaw_2 = 0;

    public Vector3 point_pos;

    // Start is called before the first frame update
    void Start()
    {
        paramserver = GameObject.Find("ParamServer");
        script = paramserver.GetComponent<ParamServer>();
        angle = script.ServoAnglesL;
    }



    // Update is called once per frame
    void Update()
    {

        point_rot_x_roll = point_rot_x_roll + point_rot_x_roll_2;
        point_rot_y_pitch = point_rot_y_pitch + point_rot_y_pitch_2;
        point_rot_z_yaw = point_rot_z_yaw + point_rot_z_yaw_2;



        point_pos = RotMat2(point_pos_x, point_pos_y, point_pos_z, point_rot_x_roll * Mathf.Deg2Rad, point_rot_y_pitch * Mathf.Deg2Rad, point_rot_z_yaw * Mathf.Deg2Rad);


        script.Point7_pos[0] = point_W_start_x;//回転の中心
        script.Point7_pos[1] = point_W_start_y;
        script.Point7_pos[2] = point_W_start_z;


        //ParamServerに送信
        script.Point5_pos[0] = point_W_start_x + point_pos_x;//回転前の位置
        script.Point5_pos[1] = point_W_start_y + point_pos_y;
        script.Point5_pos[2] = point_W_start_z + point_pos_z;

        //ParamServerに送信
        script.Point6_pos[0] = point_W_start_x + point_pos.x;//回転後の位置
        script.Point6_pos[1] = point_W_start_y + point_pos.y;
        script.Point6_pos[2] = point_W_start_z + point_pos.z;

        //script.ServoAnglesL[2] = theta;

    }

    static Vector3 RotMat2(float x, float y, float z, float dr, float dp, float dy)
    {
        double xd = x * (Math.Cos(dy) * Math.Cos(dp)) + y * (-Math.Sin(dy) * Math.Cos(dr) + Math.Cos(dy) * Math.Sin(dp) * Math.Sin(dr)) + z * (Math.Sin(dy) * Math.Sin(dr) + Math.Cos(dy) * Math.Sin(dp) * Math.Cos(dr));
        double yd = x * (Math.Sin(dy) * Math.Cos(dp)) + y * (Math.Cos(dy) * Math.Cos(dr) + (Math.Sin(dy) * Math.Sin(dp) * Math.Sin(dr))) + z * (-Math.Cos(dy) * Math.Sin(dr) + Math.Sin(dy) * Math.Sin(dp) * Math.Cos(dr));
        double zd = x * (-Math.Sin(dp)) + y * (Math.Cos(dp) * Math.Sin(dr)) + z * (Math.Cos(dp) * Math.Cos(dr));
        Vector3 val = new Vector3((float)xd, (float)yd, (float)zd);
        return val;
    }

    static Vector3 RotMat_rev(float x, float y, float z, float dr, float dp, float dy)
    {
        double xd =
              x * (Math.Cos(dy) * Math.Cos(dp)) + y * (Math.Sin(dy) * Math.Cos(dp)) + z * (-Math.Sin(dp));
        double yd =
              x * (-Math.Sin(dy) * Math.Cos(dr) + Math.Cos(dy) * Math.Sin(dp) * Math.Sin(dr)) + y * (Math.Cos(dy) * Math.Cos(dr) + (Math.Sin(dy) * Math.Sin(dp) * Math.Sin(dr))) + z * (Math.Cos(dp) * Math.Sin(dr));
        double zd =
              x * (Math.Sin(dy) * Math.Sin(dr) + Math.Cos(dy) * Math.Sin(dp) * Math.Cos(dr)) + y * (-Math.Cos(dy) * Math.Sin(dr) + Math.Sin(dy) * Math.Sin(dp) * Math.Cos(dr)) + z * (Math.Cos(dp) * Math.Cos(dr));

        Vector3 val = new Vector3((float)xd, (float)yd, (float)zd);
        return val;
    }

}