﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Point5: MonoBehaviour //腰センター点
{
    //public string lR;
    //public int iD;
    //public string aXIS;
    //public int dIRECTION;
    //private float[] angle;
    private GameObject paramserver;
    private ParamServer script;

    // Start is called before the first frame update
    void Start()
    {
        paramserver = GameObject.Find("ParamServer");
    }

    // Update is called once per frame
    void Update()
    {

        //ParamaServerの位置情報を読み込んで反映
        script = paramserver.GetComponent<ParamServer>();

        Vector3 pos = this.transform.position;

        //ROS-UNITY座標系組み替えて反映
        pos.x = -(float)script.Point5_pos[1];
        pos.y = (float)script.Point5_pos[2];
        pos.z = (float)script.Point5_pos[0];

        this.transform.position = pos;

    }
}