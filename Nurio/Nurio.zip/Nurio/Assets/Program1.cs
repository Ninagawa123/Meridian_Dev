﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Program1 : MonoBehaviour
{
    private GameObject paramserver;
    private ParamServer script;

    private float[] angle;

    public float theta = 0f;

    public float[] eax = new float[3];
    public float[] eay = new float[3];
    public float[] eaz = new float[3];


    //肩の絶対座標
    public float point_W_start_x = 0;
    public float point_W_start_y = 0.09665f;
    public float point_W_start_z = 0.4835f;

    public float point_x = 0;
    public float point_y = 0;
    public float point_z = 0;

    // Start is called before the first frame update
    void Start()
    {
        paramserver = GameObject.Find("ParamServer");
        script = paramserver.GetComponent<ParamServer>();
        angle = script.ServoAnglesL;
    }



    // Update is called once per frame
    void Update()
    {
        float sin = Mathf.Sin(theta * Mathf.Deg2Rad);
        float cos = Mathf.Cos(theta * Mathf.Deg2Rad);

        eax[0] = 1;//x
        eax[1] = 0;//y
        eax[2] = 0;//z

        eay[0] = 0;
        eay[1] = cos;
        eay[2] = sin;

        eaz[0] = 0;
        eaz[1] = -sin;
        eaz[2] = cos;

        //ROS-UNITY座標系組み替え
        //Vector3 ueax = new Vector3(eax[1], eax[2], eax[0]);
        //Vector3 ueay = new Vector3(eay[1], eay[2], eay[0]);
        //Vector3 ueaz = new Vector3(eaz[1], eaz[2], eaz[0]);

        point_x=0;
        point_y=0.3f;
        point_z=0.3f;

        //ParamServerに送信
        script.Point1_pos[0] = point_x;
        script.Point1_pos[1] = point_y;
        script.Point1_pos[2] = point_z;

        script.ServoAnglesL[2] = theta;

    }
}

        /*
        { script = paramserver.GetComponent<ParamServer>();

        if (lR == "L")
        {
            angle = script.ServoAnglesL;
        }
        else
        {
            angle = script.ServoAnglesR;
        }

        Vector3 rot = this.transform.localEulerAngles;

        rot.x = 0;
        rot.y = 0;
        rot.z = 0;

        if (aXIS == "Y")
        {
            rot.y = angle[iD] * dIRECTION;
        }
        else if (aXIS == "Z")
        {
            rot.z = angle[iD] * dIRECTION;
        }
        else
        {
            rot.x = angle[iD] * dIRECTION;
        }

        this.transform.localEulerAngles = rot;

    }
}

*/