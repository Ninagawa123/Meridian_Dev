﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ID : MonoBehaviour
{
    public string lR;
    public int iD;
    public string aXIS;
    public int dIRECTION;
    private float[] angle;
    private GameObject paramserver;
    private ParamServer script;

    // Start is called before the first frame update
    void Start()
    {
        paramserver = GameObject.Find("ParamServer");
    }

    // Update is called once per frame
    void Update()
    {
        script = paramserver.GetComponent<ParamServer>();

        if (lR == "L")
        {
            angle = script.ServoAnglesL;
        }
        else
        {
            angle = script.ServoAnglesR;
        }

        Vector3 rot = this.transform.localEulerAngles;

        rot.x = 0;
        rot.y = 0;
        rot.z = 0;

        if (aXIS == "Y")
        {
            rot.y = angle[iD] * dIRECTION;
        }
        else if (aXIS == "Z")
        {
            rot.z = angle[iD] * dIRECTION;
        }
        else
        {
            rot.x = angle[iD] * dIRECTION;
        }

        this.transform.localEulerAngles = rot;

    }
}