using System.Collections;
using UnityEngine;

public class MeridianLib : MonoBehaviour
{
    // コルーチンによる軽量なDelay
    public IEnumerator CoDelay(float num)
    {
        yield return new WaitForSeconds(num);
    }

    // フラグを待機するメソッド
    public IEnumerator WatchFlagCoroutine(bool _flag, float _sec, int _times) //何秒単位で何回チェックするか. sec=0.001f, times=8
    {
        //int waitIterations = 8; // 8回の反復でsec秒待機
        int _iteration = 0;

        while (true)
        {
            if (_flag)
            {
                // フラグが true のときに実行する処理
                break; // ループを終了し、コルーチンの実行を終了
            }

            if (_iteration < _times)
            {
                // secミリ秒待機
                yield return new WaitForSeconds(_sec);
                _iteration++;
            }
            else
            {
                break; // sec*times秒経過したのでループを終了
            }
        }
    }

    // チェックサムの計算
    public short Cksm_val(short[] _array, int _len)
    {
        long _checksum = 0;
        for (int i = 0; i < _len - 1; i++)
        {
            _checksum += _array[i];
        }
        return (short)~_checksum;
    }

    // チェックサムの判定
    public bool Cksm_rslt(short[] _array, int _len)
    {
        long _checksum = 0;
        for (int i = 0; i < _len - 1; i++)
        {
            _checksum += _array[i];
        }

        if ((short)~_checksum == _array[_len - 1])
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
