﻿using UnityEngine;
using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;

public class UdpReceiver : MonoBehaviour
{
    private MeridianData mrdData; // MrdDataのインスタンスを格納するフィールド
    private MeridianLib mrdLib; // Meridianの独自関数

    private UdpClient udpClient;
    private CancellationTokenSource cancellationTokenSource;
    private int meridimLength = MeridianConfig.meridimLength;// バッファの受信データ数
    private int receiveLength = MeridianConfig.meridimLength * 2;// バッファの受信バイト数
    private Task receiveTask;// UDP受信タスク

    public String ReceiveIpAddress;
    private String IPv6;
    public int ReceivePort = NetworkKeys.ReceivePort1;

    public short[] r_meridim = new short[MeridianConfig.meridimLength];
    public short[] r_meridim_buff = new short[MeridianConfig.meridimLength];

    private void Start()
    {
        // 必要なコンポーネントの取得
        mrdData = GetComponent<MeridianData>();
        if (mrdData == null) { Debug.LogError("MeridianData コンポーネントが見つかりません。"); return; }

        mrdLib = GetComponent<MeridianLib>();
        if (mrdLib == null) { Debug.LogError("MeridianLib コンポーネントが見つかりません。"); return; }

        if (string.IsNullOrEmpty(ReceiveIpAddress))
        {
            //(IPv4, IPv6) = IPAddressUtility;
            (ReceiveIpAddress, IPv6) = IPAddressUtility.GetLocalIPAddress();

        }

        if (ReceivePort == 0)
        {
            // 値が設定されていない場合、デフォルト値を設定
            ReceivePort = NetworkKeys.ReceivePort1;
        }


        // UDPクライアントの初期化
        InitializeUDPClient();
    }

    // UDPクライアントの初期化
    private void InitializeUDPClient()
    {
        // UdpClientの初期化
        udpClient = new UdpClient(ReceivePort);

        // CancellationTokenSourceの初期化
        cancellationTokenSource = new CancellationTokenSource();

        // 受信タスクの開始
        receiveTask = Task.Run(() => StartReceiveTask(cancellationTokenSource.Token));
    }

    // UDP受信タスク
    private async Task StartReceiveTask(CancellationToken cancellationToken)
    {
        MeridianData.MrdDataUnit mrd1 = mrdData.mrdDataUnitMaster1;

        try
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                UdpReceiveResult result = await udpClient.ReceiveAsync().ConfigureAwait(false);
                byte[] receivedData = result.Buffer;

                if (receivedData.Length == receiveLength) // ESP32からの180バイトのデータを確認
                {
                    ProcessReceivedData(receivedData);
                    mrd1.flag_udp_r_rsvd = true;
                }
            }
        }
        catch (ObjectDisposedException)
        {
            // UdpClient が閉じられた場合はここに到達する
        }
        catch (Exception ex)
        {
            Debug.LogError($"UDP受信エラー: {ex.Message}");
        }
    }

    // 受信データの処理
    private void ProcessReceivedData(byte[] data)
    {
        for (int i = 0; i < MeridianConfig.meridimLength; i++)
        {
            r_meridim_buff[i] = BitConverter.ToInt16(data, i * 2);
        }

        //if (mrdLib.Cksm_val(r_meridim_buff, meridimLength) == r_meridim_buff[meridimLength - 1])
        if (mrdLib.Cksm_rslt(r_meridim_buff, meridimLength))
        {
            MeridianData.MrdDataUnit mrd1 = mrdData.mrdDataUnitMaster1;//MeridianDataのインスタンスを取得

            for (int i = 0; i < MeridianConfig.meridimLength; i++)
            {
                r_meridim[i] = BitConverter.ToInt16(data, i * 2);
                mrd1.r_meridim[i] = BitConverter.ToInt16(data, i * 2);
            }
        }
    }

    // オブジェクト破棄時のクリーンアップ処理
    private void OnDestroy()
    {
        Cleanup();
    }

    // アプリケーション終了時のクリーンアップ処理
    private void OnApplicationQuit()
    {
        Cleanup();
    }

    // リソースのクリーンアップ処理
    private void Cleanup()
    {
        // CancellationTokenSource オブジェクトをキャンセル
        if (cancellationTokenSource != null)
        {
            cancellationTokenSource.Cancel();
            cancellationTokenSource.Dispose(); // リソースを解放
            cancellationTokenSource = null; // 参照をnullに設定
        }

        // UdpClient オブジェクトを閉じる
        if (udpClient != null)
        {
            udpClient.Close(); // UdpClient を閉じます
            udpClient = null; // 参照をnullに設定
        }
    }


    // 自身のIPアドレスを取得する
    public class IPAddressUtility
    {
        public static (string IPv4, string IPv6) GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            var IPv4 = host.AddressList.FirstOrDefault(ip => ip.AddressFamily == AddressFamily.InterNetwork)?.ToString();
            var IPv6 = host.AddressList.FirstOrDefault(ip => ip.AddressFamily == AddressFamily.InterNetworkV6)?.ToString();

            if (IPv4 == null && IPv6 == null)
            {
                throw new Exception("No network adapters with an IPv4 or IPv6 address in the system!");
            }

            return (IPv4, IPv6);
        }
    }

}