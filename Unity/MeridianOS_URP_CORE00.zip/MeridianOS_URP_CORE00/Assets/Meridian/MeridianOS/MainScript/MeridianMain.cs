using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using System.Threading;
using System.Threading.Tasks;

// Meridianのメイン処理

public class MeridianMain : MonoBehaviour
{
    // MeridianMainクラスのフィールド定義
    private MeridianData mrdData; //MrdDataのインスタンス
    private MeridianLib mrdLib;   //Meridianの独自関数のインスタンス
    private UdpSender udpSender;  //UDP送信のインスタンス
    private MainClass main1;      //メインクラスのインスタンス

    // 表示用フィールドの準備
    public float[] l_angles = new float[MeridianConfig.dofsLeft];  //L系統関節角度の表示用
    public float[] r_angles = new float[MeridianConfig.dofsRight]; //R系統関節角度の表示用

    // 変数用フィールドの準備
    private float elapsedTime = 0.0f; //動作テスト用サンプルモーション生成用の変数

    public class MainClass
    {
        //private int mrdLen = MeridianData.mrdLenStc;//Meridianのデータ長
        private static int dofsL = MeridianConfig.dofsLeft;//左系統のサーボ数
        private static int dofsR = MeridianConfig.dofsRight;//右系統のサーボ数

        //モーション用のカウンタ表示
        public int motion_count = 0;

        //UI上のスイッチ状態の判定用
        public bool demoMotionToggle = false;//計算制御テスト用トグルのインスペクター表示用
        public bool resvToggle = false;//計算制御テスト用トグルのインスペクター表示用
        public bool sendToggle = false;//計算制御テスト用トグルのインスペクター表示用
    }

    private void Awake()
    {
        main1 = new MainClass(); //重要な儀式

        // Vsync Count を 0にし、FPS を固定
        QualitySettings.vSyncCount = 0;
        Application.targetFrameRate = 400;
    }

    void Start()
    {
        mrdData = GetComponent<MeridianData>();
        if (mrdData == null) { Debug.LogError("MeridianData コンポーネントが見つかりません。"); return; }

        mrdLib = GetComponent<MeridianLib>();
        if (mrdLib == null) { Debug.LogError("MeridianLib コンポーネントが見つかりません。"); return; }

        udpSender = GetComponent<UdpSender>();
        if (udpSender == null) { Debug.LogError("UdpSender コンポーネントが見つかりません。"); return; }
    }

    void FixedUpdate()//Meridianデータの計算
    {
        MeridianData.MrdDataUnit mrd1 = mrdData.mrdDataUnitMaster1;// mrdDataUnitMaster1インスタンスにアクセス
        mrd1.motion_count++;// モーション用のカウントを加算

        //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        //::: 基本管理 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        mrd1.resvToggle = false;//UDP受信用トグル（仮おき）
        mrd1.sendToggle = false;//UDP送信用トグル（仮おき）
        mrd1.demoMotionToggle = false;//デモモーション反映トグル（仮おき）

        //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        //::: 計算で動かす場合の数値を書き込む（デモ用モーション） :::::::::::::::::::::::::::::::::::::::::::::::::::::
        //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        if (mrd1.demoMotionToggle)
        {
            for (int i = 0; i < mrd1.dofs_LR; i++)//ServoAngles_LRをインスペクター表示用に転記
            {
                mrd1.ServoAngles_L_diff[i] = mrd1.ServoAngles_L_motion[i];
                mrd1.ServoAngles_R_diff[i] = mrd1.ServoAngles_R_motion[i];
            }
        }

        //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        //::: UDPの受信およびマスターデータへの書き込み完了待ち :::::::::::::::::::::::::::::::::::::::::::::::::::::::
        //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        if (mrd1.resvToggle)// そもそもUDP受信を行うかどうか
        {
            //
        }


        //:::::::: マスターデータでのr_meridim→s_meridim転記 ::::::::::::::::::::::::::::::::::::::::::::::::

        // UDPの受信フラグの待機
        StartCoroutine(mrdLib.WatchFlagCoroutine(mrd1.flag_udp_r_rsvd, 0.001f, 8));//何秒単位で何回チェックするか. フラグ, sec=0.001f, times=8

        Array.Copy(mrd1.r_meridim, mrd1.s_meridim, mrd1.s_meridim.Length);

        mrd1.flag_udp_r_rsvd = false;

        for (int i = 0; i < mrd1.dofs_LR; i++)
        {
            //まずサーボ位置の受信結果をLRともいったん代入
            mrd1.ServoAngles_L_rslt[i] = mrd1.ServoAngles_L_init[i] + (mrd1.r_meridim[(i * 2) + 21] / 100f * mrd1.ServoAngles_L_pn[i]);
            mrd1.ServoAngles_R_rslt[i] = mrd1.ServoAngles_R_init[i] + (mrd1.r_meridim[(i * 2) + 51] * 0.01f * mrd1.ServoAngles_R_pn[i]);
            mrd1.ServoAngles_L_tgt[i] = mrd1.ServoAngles_L_rslt[i];
            mrd1.ServoAngles_R_tgt[i] = mrd1.ServoAngles_R_rslt[i];

            //:::::::: L系統の処理 ::::::::
            if (mrd1.ServoCommand_L_s[i] == 0) //サーボのコマンドが0ならサーボ実機は脱力なので受信位置データを画面に反映
            {
                if (Mathf.Abs(mrd1.ServoAngles_L_tgt[i] - mrd1.ServoAngles_L_past[i]) > 0.8)//誤差が0.8より大なら反映（表示プルプルの防止）
                {
                    //サーボの現在位置 = サーボの初期補正値 + (サーボの移動差分*サーボの回転補正値)
                    mrd1.ServoAngles_L_tgt[i] = mrd1.ServoAngles_L_init[i] + (mrd1.ServoAngles_L_diff[i] * mrd1.ServoAngles_L_pn[i]);
                    mrd1.ServoAngles_L_past[i] = mrd1.ServoAngles_L_tgt[i];//現在のサーボ位置を次回用の過去位置としてキープ
                }
                else
                {
                    mrd1.ServoAngles_L_tgt[i] = mrd1.ServoAngles_L_past[i];//移動差分が0.8未満なら位置は前回と同じにする
                }
            }
            else //サーボのコマンドが0以外ならサーボ実機は電源オンなので位置データを送信
            {
                /*
                if (mrd1.demoMotionToggle)//UIのアクショントグルがオンなら、計算したモーションデータをサーボの移動差分データとする
                {
                    mrd1.ServoAngles_L_diff[i] = mrd1.ServoAngles_L_motion[i];
                }
                else//UIのアクショントグルがオフなら、スライダーのデータをサーボの移動差分データとする
                {
                    mrd1.ServoAngles_L_diff[i] = mrd1.ServoAngles_L_UI[i];
                }
                mrd1.ServoAngles_L_past[i] = mrd1.ServoAngles_L_diff[i];//現在のサーボ位置を次回用の過去位置としてキープ
                */
            }

            //:::::::: R系統の処理 ::::::::
            if (mrd1.ServoCommand_R_s[i] == 0)//サーボのコマンドが0ならサーボ実機は脱力なので受信位置データを画面に反映

            {
                if (Mathf.Abs(mrd1.ServoAngles_R_tgt[i] - mrd1.ServoAngles_R_past[i]) > 0.8)//誤差が0.8より大なら反映（表示プルプルの防止）
                {
                    //サーボの現在位置 = サーボの初期補正値 + (サーボの移動差分*サーボの回転補正値)
                    mrd1.ServoAngles_R_tgt[i] = mrd1.ServoAngles_R_init[i] + (mrd1.ServoAngles_R_diff[i] * mrd1.ServoAngles_R_pn[i]);
                    mrd1.ServoAngles_R_past[i] = mrd1.ServoAngles_R_tgt[i];//現在のサーボ位置を次回用の過去位置としてキープ
                }
                else
                {
                    mrd1.ServoAngles_R_tgt[i] = mrd1.ServoAngles_R_past[i];//移動差分が0.8未満なら位置は前回と同じにする
                }
            }
            else //サーボのコマンドが0以外ならサーボ実機は電源オンなので位置データを送信
            {
                /*
                if (mrd1.demoMotionToggle)//UIのアクショントグルがオンなら、計算したモーションデータをサーボの移動差分データとする
                {
                    mrd1.ServoAngles_R_diff[i] = mrd1.ServoAngles_R_motion[i];
                }
                else//UIのアクショントグルがオフなら、スライダーのデータをサーボの移動差分データとする
                {
                    mrd1.ServoAngles_R_diff[i] = mrd1.ServoAngles_R_UI[i];
                }
                mrd1.ServoAngles_R_past[i] = mrd1.ServoAngles_R_diff[i];//現在のサーボ位置を次回用の過去位置としてキープ
                */
            }

            //:::::::: mastercommandの処理 ::::::::
            if (mrd1.mastercommand_s == 10002)
            {
                mrd1.s_meridim[0] = 10002;//#IMUのヨー軸センターリセットコマンド
                mrd1.mastercommand_s = 90;//90はマスターコマンドのデフォルト値
            }

        }

        //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        //::: 送信データs_meridimの作成処理 ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

        //mrd1.flag_udp_s_busy = true;//trueならs_meridim_udpが書き込み中（なので読み取り禁止）というフラグ

        // サーボ位置とサーボコマンドの転記
        for (int i = 0; i < mrd1.dofs_LR; i++)
        {
            mrd1.s_meridim[(i * 2) + 20] = (short)(mrd1.ServoCommand_L_s[i]);//サーボコマンドの転記
            mrd1.s_meridim[(i * 2) + 50] = (short)(mrd1.ServoCommand_R_s[i]);
            mrd1.s_meridim[i * 2 + 21] = (short)Mathf.Round(mrd1.ServoAngles_L_tgt[i] * 100);//サーボ位置
            mrd1.s_meridim[i * 2 + 51] = (short)Mathf.Round(mrd1.ServoAngles_R_tgt[i] * 100);
        }
        mrd1.s_meridim[0] = 90;//サーボコマンドの転記
        mrd1.s_meridim[20] = 1;//サーボコマンドの転記

        // 経過時間を更新
        elapsedTime += Time.deltaTime;

        // サインカーブに沿った角度を計算（周期を5秒とする）
        float angle = 6000 * Mathf.Sin(2 * Mathf.PI * elapsedTime / 5.0f);

        // サインカーブに沿った角度を計算（周期を5秒とする）
        mrd1.s_meridim[21] = (short)angle;//サーボコマンドの転記


        //<2-1>チェックサムの作成
        mrd1.s_meridim[MeridianConfig.meridimLength - 1] = mrdLib.Cksm_val(mrd1.s_meridim, MeridianConfig.meridimLength);

        //:::::::: s_meridimの作成処理ここまで ::::::::

        // Meridimデータの送信
        mrd1.flag_udp_s_ready = true;//送信フラグ揚げ
    }

    private void Update()
    {
        MeridianData.MrdDataUnit mrd1 = mrdData.mrdDataUnitMaster1;//データのインスタンスを取得

        //:::::::: インスペクター表示用の転記処理 ::::::::
        main1.resvToggle = mrd1.resvToggle;//スライダ値送信用トグル
        main1.sendToggle = mrd1.sendToggle;//スライダ値送信用トグル
        main1.demoMotionToggle = mrd1.demoMotionToggle;//計算制御テスト用のトグル
        main1.motion_count = mrd1.motion_count;//モーション用のカウントアップ

    }
}
