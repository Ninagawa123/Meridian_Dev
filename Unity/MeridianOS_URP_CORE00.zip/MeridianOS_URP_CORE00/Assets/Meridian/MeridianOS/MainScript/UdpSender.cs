﻿using UnityEngine;
using System;
using System.Collections;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;
using Diagnostics = System.Diagnostics;

public class UdpSender : MonoBehaviour
{
    private MeridianData mrdData; // MrdDataのインスタンスを格納するフィールド
    private MeridianLib mrdLib; // Meridianの独自関数
    private UdpClient udpClient;
    private IPEndPoint remoteEndPoint;
    string remoteIPAddress; // 送信先のIPアドレス用キャッシュ
    int remotePort; // 送信先のポート番号格納用キャッシュ
    private float _timeout; //ループ抜け用のキャッシュ
    private bool _isRunning; //ループ抜け用のフラグ
    int _s_packet_len; //Meridimの長さ
    byte[] _s_packet_byte;

    public String SendIpAddress = NetworkKeys.EspIp1;
    public int SendePort = NetworkKeys.SendPort1;
    private String IPv6;

    public short[] s_meridim = new short[MeridianConfig.meridimLength];

    Diagnostics.Stopwatch stopwatch = new Diagnostics.Stopwatch(); //ループ抜け用のストップウォッチ

    void Start()
    {
        // 必要なコンポーネントの取得
        mrdData = GetComponent<MeridianData>();
        if (mrdData == null) { Debug.LogError("MeridianData コンポーネントが見つかりません。"); return; }

        mrdLib = GetComponent<MeridianLib>();
        if (mrdLib == null) { Debug.LogError("MeridianLib コンポーネントが見つかりません。"); return; }

        _isRunning = true; //ループ抜け用のフラグ

        if (string.IsNullOrEmpty(SendIpAddress))
        {
            // 値が設定されていない場合、デフォルト値を設定
            SendIpAddress = NetworkKeys.EspIp1;
        }

        if (SendePort == 0)
        {
            // 値が設定されていない場合、デフォルト値を設定
            SendePort = NetworkKeys.SendPort1;
        }

        // UDPクライアントの初期化
        InitializeUdpClient();

        // フラグ監視＆UDP送信用のコルーチンの開始
        StartCoroutine(WatchFlagAndSendData());

    }

    // UDPクライアントの初期化
    private void InitializeUdpClient()
    {
        remoteIPAddress = NetworkKeys.EspIp1; // 送信先のIPアドレス
        remotePort = NetworkKeys.SendPort1; // 送信先のポート番号
        remoteEndPoint = new IPEndPoint(IPAddress.Parse(remoteIPAddress), remotePort);
        udpClient = new UdpClient();
    }


    // フラグ監視＆UDP送信用のコルーチン
    IEnumerator WatchFlagAndSendData()
    {
        MeridianData.MrdDataUnit mrd1 = mrdData.mrdDataUnitMaster1;// mrdDataUnitMaster1インスタンスにアクセス
        _s_packet_len = mrd1.s_meridim.Length;
        _s_packet_byte = new byte[_s_packet_len * 2];
        _timeout = mrd1.udp_resv_timeout;

        while (_isRunning)
        {
            // フラグタイムアウト用のストップウォッチの開始
            stopwatch.Reset();
            stopwatch.Start();

            // 送信準備完了フラグの監視
            while (stopwatch.Elapsed.TotalSeconds < _timeout)
            {
                if (mrd1.flag_udp_s_ready)// 送信準備完了を検知した時の処理
                {
                    mrd1.flag_udp_s_ready = false;

                    //送信用のバイトを作成
                    for (int i = 0; i < _s_packet_len; i++)
                    {
                        byte[] byteArray = BitConverter.GetBytes(mrd1.s_meridim[i]);
                        _s_packet_byte[i * 2] = (byte)byteArray[0];
                        _s_packet_byte[i * 2 + 1] = (byte)byteArray[1];
                        s_meridim[i] = mrd1.s_meridim[i];
                    }

                    // 非同期の送信タスクを開始
                    Task sendTask = null;
                    try
                    {
                        sendTask = udpClient.SendAsync(_s_packet_byte, _s_packet_byte.Length, remoteEndPoint);
                    }
                    catch (Exception ex)
                    {
                        Debug.LogError($"UDP送信開始時のエラー: {ex.Message}");
                        continue; // 次のループへ進む
                    }

                    // タスクが完了するまで待機
                    yield return new WaitUntil(() => sendTask != null && sendTask.IsCompleted);

                    // タスクの例外をチェック
                    if (sendTask.Exception != null)
                    {
                        // カスタムエラーメッセージを表示
                        Debug.LogWarning("送信先のホストに到達できません。接続先デバイスのIPアドレスおよび起動状態を確認してください。");
                    }
                    else
                    {
                        // 送信成功時の処理
                    }
                }
            }
            stopwatch.Stop();
            yield return null;
        }
    }

    // オブジェクト破棄時のクリーンアップ処理
    private void OnDestroy()
    {
        Cleanup();
    }

    // アプリケーション終了時のクリーンアップ処理
    private void OnApplicationQuit()
    {
        Cleanup();
    }

    // リソースのクリーンアップ処理
    private void Cleanup()
    {
        _isRunning = false;
        StopAllCoroutines(); // すべてのコルーチンを停止

        if (udpClient != null)
        {
            udpClient.Close();
            udpClient = null;
        }
    }
}