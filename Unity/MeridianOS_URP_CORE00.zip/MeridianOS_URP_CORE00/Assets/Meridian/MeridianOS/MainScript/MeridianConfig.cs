using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeridianConfig : MonoBehaviour
{
    // Meridim配列の初期設定
    public static int meridimLength = 90;// meridimの長さ（デフォルトは90）
    public static int dofsLeft = 20; // L系のサーボ数（デフォルトは20）
    public static int dofsRight = 20; // R系のサーボ数（デフォルトは20）
    public static int timeOutMs = 50; // UnityのUDP送受信タイムアウト（ミリ秒）
    public static float FixedFps { get; set; } = 0.01f; //Meridianのフレームレート
    public static float udpResvTimeout = 0.008f; //1フレーム(デフォルトは10ms)中のUDP受信待機のタイムアウト

    //サーボの初期位置補正（degreeで指定）
    //※ハード側の補正値はTeensyで指定。こちらはUnity側の計算および表示での補正用。
    public static float[] ServoAngles_L_init { get; set; } = {
        0f, // L系 0番のサーボ
        0f, // L系 1番のサーボ
        0f, // L系 2番のサーボ
        0f, // L系 3番のサーボ
        0f, // L系 4番のサーボ
        0f, // L系 5番のサーボ
        0f, // L系 6番のサーボ
        0f, // L系 7番のサーボ
        0f, // L系 8番のサーボ
        0f, // L系 9番のサーボ
        0f, // L系 10番のサーボ
        0f, // L系 11番のサーボ
        0f, // L系 12番のサーボ
        0f, // L系 13番のサーボ
        0f, // L系 14番のサーボ
        0f, // L系 15番のサーボ
        0f, // L系 16番のサーボ
        0f, // L系 17番のサーボ
        0f, // L系 18番のサーボ
        0f, // L系 19番のサーボ
        };

    public static float[] ServoAngles_R_init { get; set; } = {
        0f, // R系 0番のサーボ
        0f, // R系 1番のサーボ
        0f, // R系 2番のサーボ
        0f, // R系 3番のサーボ
        0f, // R系 4番のサーボ
        0f, // R系 5番のサーボ
        0f, // R系 6番のサーボ
        0f, // R系 7番のサーボ
        0f, // R系 8番のサーボ
        0f, // R系 9番のサーボ
        0f, // R系 10番のサーボ
        0f, // R系 11番のサーボ
        0f, // R系 12番のサーボ
        0f, // R系 13番のサーボ
        0f, // R系 14番のサーボ
        0f, // R系 15番のサーボ
        0f, // R系 16番のサーボ
        0f, // R系 17番のサーボ
        0f, // R系 18番のサーボ
        0f, // R系 19番のサーボ
        };


    //サーボ回転方向の正負方向補正（正なら1,負なら-1）
    //※ハード側の補正値はTeensyで指定。こちらはUnity側の計算および表示での補正用。
    public static float[] ServoAngles_L_pn { get; set; } = {
        1f, // L系 0番のサーボ
        1f, // L系 1番のサーボ
        1f, // L系 2番のサーボ
        1f, // L系 3番のサーボ
        1f, // L系 4番のサーボ
        1f, // L系 5番のサーボ
        1f, // L系 6番のサーボ
        1f, // L系 7番のサーボ
        1f, // L系 8番のサーボ
        1f, // L系 9番のサーボ
        1f, // L系 10番のサーボ
        1f, // L系 11番のサーボ
        1f, // L系 12番のサーボ
        1f, // L系 13番のサーボ
        1f, // L系 14番のサーボ
        1f, // L系 15番のサーボ
        1f, // L系 16番のサーボ
        1f, // L系 17番のサーボ
        1f, // L系 18番のサーボ
        1f, // L系 19番のサーボ
        };

    public static float[] ServoAngles_R_pn { get; set; } = {
        1f, // R系 0番のサーボ
        1f, // R系 1番のサーボ
        1f, // R系 2番のサーボ
        1f, // R系 3番のサーボ
        1f, // R系 4番のサーボ
        1f, // R系 5番のサーボ
        1f, // R系 6番のサーボ
        1f, // R系 7番のサーボ
        1f, // R系 8番のサーボ
        1f, // R系 9番のサーボ
        1f, // R系 10番のサーボ
        1f, // R系 11番のサーボ
        1f, // R系 12番のサーボ
        1f, // R系 13番のサーボ
        1f, // R系 14番のサーボ
        1f, // R系 15番のサーボ
        1f, // R系 16番のサーボ
        1f, // R系 17番のサーボ
        1f, // R系 18番のサーボ
        1f, // R系 19番のサーボ
        };
}
