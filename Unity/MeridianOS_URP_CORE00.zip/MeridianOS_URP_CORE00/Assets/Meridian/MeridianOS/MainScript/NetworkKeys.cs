using UnityEngine;

public class NetworkKeys : MonoBehaviour
{
    public static string EspIp1 = "192.168.1.19"; //送信先(ESP32)のIPアドレス
    public static int ReceivePort1 = 22222;//受信に使うポートの番号
    public static int SendPort1 = 22224;//送信用ポート設定
}
