
//using System.Collections;
//using System.Collections.Generic;
using System;
using UnityEngine;
//using System.Threading;

public class MeridianData : MonoBehaviour
{
    public MrdDataUnit mrdDataUnitMaster1; // クラスのインスタンス

    // 表示用フィールドの準備
    public short[] meridim_resv = new short[MeridianConfig.meridimLength];//meridim90の受信値表示用
    public short[] meridim_send = new short[MeridianConfig.meridimLength];//meridim90の送信値表示用
    public float[] l_target = new float[MeridianConfig.dofsLeft];//L系統関節角度の表示用
    public float[] r_target = new float[MeridianConfig.dofsRight];//R系統関節角度の表示用
    public float[] l_result = new float[MeridianConfig.dofsLeft];//L系統関節角度の表示用
    public float[] r_result = new float[MeridianConfig.dofsRight];//R系統関節角度の表示用

    //public float motion_sample_val;//
    public float sample_val; // デフォルトは動作確認用のサンプルとなる値.L0番サーボの受信値

    // Awakeでインスタンスを初期化
    private void Awake()
    {
        mrdDataUnitMaster1 = new MrdDataUnit();
        mrdDataUnitMaster1.mrd_len = MeridianConfig.meridimLength;// meridimの長さ（デフォルトは90）
        mrdDataUnitMaster1.dofs_L = MeridianConfig.dofsLeft;// L系のサーボ数（デフォルトは20）
        mrdDataUnitMaster1.dofs_R = MeridianConfig.dofsRight;// L系のサーボ数（デフォルトは20）
        mrdDataUnitMaster1.dofs_LR = Math.Max(mrdDataUnitMaster1.dofs_L, mrdDataUnitMaster1.dofs_R); // LR系のサーボ数の大きい方
        mrdDataUnitMaster1.timeout = MeridianConfig.timeOutMs;// L系のサーボ数（デフォルトは20）
        mrdDataUnitMaster1.udp_resv_timeout = MeridianConfig.udpResvTimeout; //1フレーム(デフォルトは10ms)中のUDP受信待機のタイムアウト

        //変数のゼロリセット
        for (int i = 0; i < MeridianConfig.meridimLength; i++)
        {
            mrdDataUnitMaster1.r_meridim[i] = 0;
            mrdDataUnitMaster1.s_meridim[i] = 0;
            mrdDataUnitMaster1.s_meridim_packet_byte[i * 2] = 0;
            mrdDataUnitMaster1.s_meridim_packet_byte[(i * 2) + 1] = 0;
        }

        for (int i = 0; i < MeridianConfig.dofsLeft; i++)
        {
            mrdDataUnitMaster1.ServoCommand_L_r[i] = 0;
            mrdDataUnitMaster1.ServoCommand_L_s[i] = 0;
            mrdDataUnitMaster1.ServoAngles_L_UI[i] = 0f;
            mrdDataUnitMaster1.ServoAngles_L_init[i] = MeridianConfig.ServoAngles_L_init[i];
            mrdDataUnitMaster1.ServoAngles_L_pn[i] = MeridianConfig.ServoAngles_L_pn[i];
            mrdDataUnitMaster1.ServoAngles_L_diff[i] = 0f;
            mrdDataUnitMaster1.ServoAngles_L_past[i] = 0f;
            mrdDataUnitMaster1.ServoAngles_L_tgt[i] = 0f;
            mrdDataUnitMaster1.ServoAngles_L_rslt[i] = 0f;
            mrdDataUnitMaster1.ServoAngles_L_motion[i] = 0f;
        }

        for (int i = 0; i < MeridianConfig.dofsRight; i++)
        {
            mrdDataUnitMaster1.ServoCommand_R_r[i] = 0;
            mrdDataUnitMaster1.ServoCommand_R_s[i] = 0;
            mrdDataUnitMaster1.ServoAngles_R_UI[i] = 0f;
            mrdDataUnitMaster1.ServoAngles_R_init[i] = MeridianConfig.ServoAngles_R_init[i];
            mrdDataUnitMaster1.ServoAngles_R_pn[i] = MeridianConfig.ServoAngles_R_pn[i];
            mrdDataUnitMaster1.ServoAngles_R_diff[i] = 0f;
            mrdDataUnitMaster1.ServoAngles_R_past[i] = 0f;
            mrdDataUnitMaster1.ServoAngles_R_tgt[i] = 0f;
            mrdDataUnitMaster1.ServoAngles_R_rslt[i] = 0f;
            mrdDataUnitMaster1.ServoAngles_R_motion[i] = 0f;
        }

        for (int i = 0; i < 13; i++)
        {
            mrdDataUnitMaster1.ACxyz_GYxyz_CPxyz_TP_RPY[i] = 0f;
        }
    }


    public class MrdDataUnit// ロボット１台分のMeridimデータをまとめたクラス
    {
        public int mrd_len { get; set; }// meridimの長さ（デフォルトは90）
        public int dofs_L { get; set; }// L系のサーボ数（デフォルトは20）
        public int dofs_R { get; set; }// L系のサーボ数（デフォルトは20）
        public int dofs_LR { get; set; } // LR系のサーボ数の大きい方
        public int dofs_3rd { get; set; } // LR系のサーボ数の大きい方

        public int timeout { get; set; }// UnityのUDP送受信タイムアウト（ミリ秒）

        //meridimの値
        public short[] r_meridim { get; set; } = new short[MeridianConfig.meridimLength];//meridim90の受信用
        public short[] s_meridim { get; set; } = new short[MeridianConfig.meridimLength];//meridim90の送信用
        public byte[] s_meridim_packet_byte { get; set; } = new byte[MeridianConfig.meridimLength * 2];//データ送信格納用のshort型変数（２バイト）
        //public short[] s_meridim_udp = new short[meridimLength];//meridim90の送信用(UDP送信転記用)


        //サーボのUnityUIからの入力の一次格納用
        public float[] ServoAngles_L_UI { get; set; } = new float[MeridianConfig.dofsLeft];
        public float[] ServoAngles_R_UI { get; set; } = new float[MeridianConfig.dofsRight];
        public float[] ServoAngles_3rd_UI { get; set; }

        //サーボの初期位置補正値
        public float[] ServoAngles_L_init { get; set; } = new float[MeridianConfig.dofsLeft];
        public float[] ServoAngles_R_init { get; set; } = new float[MeridianConfig.dofsRight];
        public float[] ServoAngles_3rd_init { get; set; }

        //サーボ回転方向の正負方向補正用(pn:positive,negative)
        public float[] ServoAngles_L_pn { get; set; } = new float[MeridianConfig.dofsLeft];
        public float[] ServoAngles_R_pn { get; set; } = new float[MeridianConfig.dofsRight];
        public float[] ServoAngles_3rd_pn { get; set; }

        //サーボの移動差分
        public float[] ServoAngles_L_diff { get; set; } = new float[MeridianConfig.dofsLeft];
        public float[] ServoAngles_R_diff { get; set; } = new float[MeridianConfig.dofsRight];
        public float[] ServoAngles_3rd_diff { get; set; }

        //サーボの前回位置の値
        public float[] ServoAngles_L_past { get; set; } = new float[MeridianConfig.dofsLeft];
        public float[] ServoAngles_R_past { get; set; } = new float[MeridianConfig.dofsRight];
        public float[] ServoAngles_3rd_past { get; set; }

        //サーボの現在位置（計算後の最終結果）：サーボの初期補正値 + (サーボの移動差分 * サーボの回転補正値)
        public float[] ServoAngles_L_tgt { get; set; } = new float[MeridianConfig.dofsLeft];
        public float[] ServoAngles_R_tgt { get; set; } = new float[MeridianConfig.dofsRight];
        public float[] ServoAngles_3rd_tgt { get; set; }

        //サーボの現在位置（受信値を元にした実行結果）：サーボの初期補正値 + (サーボの移動差分 * サーボの回転補正値)
        public float[] ServoAngles_L_rslt { get; set; } = new float[MeridianConfig.dofsLeft];
        public float[] ServoAngles_R_rslt { get; set; } = new float[MeridianConfig.dofsRight];
        public float[] ServoAngles_3rd_rslt { get; set; }

        //サーボコマンド受信値
        public int[] ServoCommand_L_r { get; set; } = new int[MeridianConfig.dofsLeft];
        public int[] ServoCommand_R_r { get; set; } = new int[MeridianConfig.dofsRight];
        public int[] ServoCommand_3rd_r { get; set; }

        //サーボコマンド送信値
        public int[] ServoCommand_L_s { get; set; } = new int[MeridianConfig.dofsLeft];
        public int[] ServoCommand_R_s { get; set; } = new int[MeridianConfig.dofsRight];
        public int[] ServoCommand_3rd_s { get; set; }

        //計算モーション用のサーボ位置
        public float[] ServoAngles_L_motion { get; set; } = new float[MeridianConfig.dofsLeft];
        public float[] ServoAngles_R_motion { get; set; } = new float[MeridianConfig.dofsRight];
        public float[] ServoAngles_3rd_motion { get; set; }

        //計算モーション用の変数
        public int motion_count { get; set; } = 0;//計算モーションのカウント用
        public float motion_test_val { get; set; } = 0;//計算モーション用のテンポラリ変数

        //センサー用の配列　それぞれ100倍された値が入ってくる
        public float[] ACxyz_GYxyz_CPxyz_TP_RPY { get; set; } = new float[13];//11,12,13番がRPYの100倍値

        //UI上のスイッチ状態の判定用
        public bool demoMotionToggle { get; set; } = false;//デモモーション用トグル
        public bool resvToggle { get; set; } = false;//UDP送信用トグル
        public bool sendToggle { get; set; } = false;//UDP受信用トグル

        //コマンド格納用の変数
        public int mastercommand_s { get; set; } = 90;//meridim90の受信値
        public int mastercommand_r { get; set; } = 90;//meridim90の送信値

        //フラグ用の変数
        public bool flag_udp_r_enabled { get; set; } = true;//UDP受信を実行するかどうかのフラグ
        public bool flag_udp_s_enabled { get; set; } = true;//UDP送信を実行するかどうかのフラグ
        public bool flag_udp_r_busy { get; set; } = false;//r_meridimの読み書き中フラグ
        public bool flag_udp_s_busy { get; set; } = false;//s_meridimの読み書き中フラグ
        public bool flag_udp_r_rsvd { get; set; } = true;//r_meridimの受信完了フラグ
        public bool flag_udp_s_ready { get; set; } = true;//s_meridimの送信準備完了フラグ
        public int flag_udp_r_queue { get; set; } = 0; //r_meridim_udpの制御キュー（転記完了で+1(1)、送信完了で-1(0)）
        public int flag_udp_s_queue { get; set; } = 0; //s_meridim_udpの制御キュー（転記完了で+1(1)、送信完了で-1(0)）

        //システム用の変数
        public float udp_resv_timeout { get; set; } = 0.008f; //UDPの受信待ちのタイムアウト

    }




    private void Start()
    {
        //
    }


    private void Update()
    {
        //meridimのインスペクター表示
        for (int i = 0; i < MeridianConfig.meridimLength; i++)
        {
            meridim_resv[i] = mrdDataUnitMaster1.r_meridim[i];//meridim90の受信値表示用
            meridim_send[i] = mrdDataUnitMaster1.s_meridim[i];//meridim90の送信値表示用
        }
        //ServoAngles_L,Rのインスペクター表示
        for (int i = 0; i < mrdDataUnitMaster1.dofs_LR; i++)
        {
            l_target[i] = mrdDataUnitMaster1.ServoAngles_L_tgt[i];//左系統サーボの角度の表示用
            l_result[i] = mrdDataUnitMaster1.ServoAngles_L_rslt[i];//左系統サーボの角度の表示用
            r_target[i] = mrdDataUnitMaster1.ServoAngles_R_tgt[i];//右系統サーボの角度の表示用
            r_result[i] = mrdDataUnitMaster1.ServoAngles_R_rslt[i];//右系統サーボの角度の表示用
        }

        //motion_sample_val = mrdDataUnitMaster1.motion_test_val;
        sample_val = mrdDataUnitMaster1.ServoAngles_L_rslt[0]; // デフォルトは動作確認用のサンプルとなる値. L0番サーボの受信値

        //Debug.Log(mrdDataUnitMaster1.motion_count);

    }
}
