using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Test_Monolith_L0 : MonoBehaviour
{
    public GameObject systemGameObject; // GameObject特定用のフィールド
    private MeridianData mrdData; // インスタンス格納用のフィールド
    public float testdata = 0f; //回転テスト用

    private void Start()
    {
        systemGameObject = GameObject.Find("MeridianOS");
        mrdData = systemGameObject.GetComponent<MeridianData>();
    }

    void Update()
    {
        MeridianData.MrdDataUnit mrd1 = mrdData.mrdDataUnitMaster1;//MeridianDataのインスタンスを取得

        if (mrd1 == null)
        {
            Debug.LogError("MrdDataUnitコンポーネントが見つかりませんでした。");
        }

        testdata = mrd1.ServoAngles_L_rslt[0];
        transform.eulerAngles = new Vector3(0, mrd1.ServoAngles_L_rslt[0], 0);
    }
}